import numpy as np
import matplotlib.pyplot as plt


a = np.array([-2, 0])


plt.plot(a)
plt.show()

